#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import seaborn as sn 
import matplotlib.pyplot as plt

import warnings as w
w.filterwarnings('ignore')


# In[2]:


import os
root_path = os.getcwd()
parent_directory = os.path.dirname(root_path)
print("Root directory path:", parent_directory)


# In[3]:


df= pd.read_csv(parent_directory + '/data/Most Streamed Spotify Songs 2024.csv', encoding='latin1')
df.head(5)


# In[4]:


df.isna().sum()


# In[5]:


# Delete columns with a null ratio exceeding the threshold
missing_counts = df.isna().sum()
missing_ratios = missing_counts / len(df)

threshold = 0.5

df_cleaned = df.drop(columns=missing_ratios[missing_ratios > threshold].index)


# In[6]:


df_cleaned


# In[7]:


# Delete rows with empty Spotify Popularity
df = df_cleaned.dropna(subset=['Spotify Popularity'])
df


# In[8]:


df.columns


# In[17]:


df.fillna(df.mode().iloc[0], inplace=True)
df.isna().sum()


# In[26]:


df_cleaned = df.apply(lambda x: x.replace({',': ''}, regex=True) if x.dtype == 'object' else x)
df_cleaned = df_cleaned.apply(pd.to_numeric, errors='coerce')
# Feature and label separation
X = df_cleaned.drop(columns=['Spotify Popularity','Release Date','ISRC','Track','Album Name','Explicit Track'])
y = df_cleaned['Spotify Popularity']
from sklearn.preprocessing import StandardScaler, LabelEncoder

# Encode categorical features
label_encoder = LabelEncoder()
X['Artist'] = label_encoder.fit_transform(X['Artist'])


# In[28]:


from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# 数据集划分
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 模型训练
model = RandomForestRegressor(random_state=42)
model.fit(X_train, y_train)

# 模型预测
y_pred = model.predict(X_test)

# 评估模型
print(f"Mean Absolute Error (MAE): {mean_absolute_error(y_test, y_pred)}")
print(f"Mean Squared Error (MSE): {mean_squared_error(y_test, y_pred)}")
print(f"Root Mean Squared Error (RMSE): {mean_squared_error(y_test, y_pred, squared=False)}")
print(f"R^2 Score: {r2_score(y_test, y_pred)}")


# In[29]:


import matplotlib.pyplot as plt

# 绘制散点图
plt.figure(figsize=(8, 6))
plt.scatter(y_test, y_pred, color='blue', alpha=0.6)
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], color='red', lw=2)  # 45度线，表示完美预测
plt.xlabel('True Values')
plt.ylabel('Predictions')
plt.title('True Values vs Predicted Values')
plt.show()


# In[ ]:




