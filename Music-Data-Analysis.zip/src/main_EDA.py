#!/usr/bin/env python
# coding: utf-8

# In[15]:


import pandas as pd
import seaborn as sn 
import matplotlib.pyplot as plt
import plotly.express as px
import warnings as w
w.filterwarnings('ignore')


# In[2]:


import os
root_path = os.getcwd()
parent_directory = os.path.dirname(root_path)
print("Root directory path:", parent_directory)


# In[5]:


df= pd.read_csv(parent_directory + '/data/Most Streamed Spotify Songs 2024.csv', encoding='latin1')
df.head(5)


# In[7]:


df.columns


# 该数据集由29列组成，其中包含各种类型的信息，如曲目名称、艺术家、发布日期和各种流媒体指标

# 🎵 Track
# 📀 Album Name
# 🎤 Artist
# 📅 Release Date
# 🔢 ISRC
# 📈 All Time Rank
# ⭐ Track Score
# 🎧 Spotify Streams
# 📋 Spotify Playlist Count
# 🌐 Spotify Playlist Reach
# 🎼 Spotify Popularity
# 📹 YouTube Views
# 👍 YouTube Likes
# 🎥 TikTok Posts
# 💖 TikTok Likes
# 👁️ TikTok Views
# 🎵 YouTube Playlist Reach
# 🍏 Apple Music Playlist Count
# 📻 AirPlay Spins
# 📡 SiriusXM Spins
# 🎶 Deezer Playlist Count
# 🌍 Deezer Playlist Reach
# 📚 Amazon Playlist Count
# 🎙️ Pandora Streams
# 📻 Pandora Track Stations
# 🔊 Soundcloud Streams
# 🕵️ Shazam Counts
# 🎶 TIDAL Popularity
# 🔞 Explicit Track

# In[9]:


df.head(3)


# In[10]:


df.isna().sum()


# We identified columns with missing values:
# 
# 🎤 Artist: 5 missing values
# 🎧 Spotify Streams: 113 missing values
# 📋 Spotify Playlist Count: 70 missing values
# 🌐 Spotify Playlist Reach: 72 missing values
# 🎼 Spotify Popularity: 804 missing values
# 📹 YouTube Views: 308 missing values
# 👍 YouTube Likes: 315 missing values
# 🎥 TikTok Posts: 1173 missing values
# 💖 TikTok Likes: 980 missing values
# 👁️ TikTok Views: 981 missing values
# 🎵 YouTube Playlist Reach: 1009 missing values
# 🍏 Apple Music Playlist Count: 561 missing values
# 📻 AirPlay Spins: 498 missing values
# 📡 SiriusXM Spins: 2123 missing values
# 🎶 Deezer Playlist Count: 921 missing values
# 🌍 Deezer Playlist Reach: 928 missing values
# 📚 Amazon Playlist Count: 1055 missing values
# 🎙️ Pandora Streams: 1106 missing values
# 📻 Pandora Track Stations: 1268 missing values
# 🔊 Soundcloud Streams: 3333 missing values
# 🕵️ Shazam Counts: 577 missing values
# 🎶 TIDAL Popularity: 4600 missing values
# 🔞 Explicit Track: No missing values

# In[12]:


df.drop("TIDAL Popularity",axis=1,inplace=True)


# In[13]:


top_albums=df['Album Name'].value_counts().nlargest(50)


# In[22]:


top_albums_df = top_albums.reset_index()
top_albums_df.columns = ['Album Name', 'Count']
plt.figure(figsize=(15, 5))
sn.barplot(x='Album Name', y='Count', data=top_albums_df, palette='viridis')
plt.title('Top 50 Albums by Count', fontsize=15)
plt.xlabel('Album Name', fontsize=12)
plt.ylabel('Count', fontsize=12)
plt.xticks(rotation=45, ha='right')
plt.savefig(parent_directory + "/results/Top 50 Albums by Count.png", bbox_inches='tight')
plt.show()


# In[23]:


top_Track=df['Track'].value_counts().nlargest(50)


# In[24]:


top_Track_df = top_Track.reset_index()
top_Track_df.columns = ['Track Name', 'Count']
plt.figure(figsize=(15, 5))
sn.barplot(x='Track Name', y='Count', data=top_Track_df, palette='viridis')
plt.title('Top 50 Track by Count', fontsize=15)
plt.xlabel('Track Name', fontsize=12)
plt.ylabel('Count', fontsize=12)
plt.xticks(rotation=45, ha='right')
plt.savefig(parent_directory + "/results/Top 50 Track by Count.png", bbox_inches='tight')
plt.show()


# In[25]:


top_Artist=df['Artist'].value_counts().nlargest(50)
top_Artist


# In[26]:


top_Track_df = top_Artist.reset_index()
top_Track_df.columns = ['Artist Name', 'Count']
plt.figure(figsize=(15, 5))
sn.barplot(x='Artist Name', y='Count', data=top_Track_df, palette='viridis')
plt.title('Top 50 Artist by Count', fontsize=15)
plt.xlabel('Artist Name', fontsize=12)
plt.ylabel('Count', fontsize=12)
plt.xticks(rotation=45, ha='right')
plt.savefig(parent_directory + "/results/Top 50 Artist by Count.png", bbox_inches='tight')
plt.show()


# In[27]:


top_ranked_artist=df[['Artist','All Time Rank']]
top_20artist=top_ranked_artist.head(20)
top_20artist


# In[29]:


plt.title("TOP 20 ARTIST BY RANK ON SPOTIFY")
plt.xlabel("ARTIST NAME")
sn.barplot(x=top_20artist['Artist'],y=top_20artist['All Time Rank'],palette='viridis')
plt.xticks(rotation=65)
plt.savefig(parent_directory + "/results/TOP 20 ARTIST BY RANK ON SPOTIFY.png", bbox_inches='tight')
plt.show()


# In[30]:


least_20artist=top_ranked_artist.tail(20)
least_20artist


# In[31]:


plt.title("LEAST POPULAR TOP 20 ARTIST BY RANK ON SPOTIFY")
plt.xlabel("ARTIST NAME")
plt.ylabel("ALL TIME RANK")
sn.barplot(x=least_20artist['Artist'],y=least_20artist['All Time Rank'],palette='viridis')
plt.xticks(rotation=75)
plt.savefig(parent_directory + "/results/LEAST POPULAR TOP 20 ARTIST BY RANK ON SPOTIFY.png", bbox_inches='tight')
plt.show()


# In[32]:


about_track=df[['Track','Album Name','Artist','Track Score']]
top_20det_Tr=about_track.head(20)
top_20det_Tr.head(20)


# In[33]:


fig, axes = mp.subplots(3, 1, figsize=(14, 18))
spine_colors = ['#FF5733', '#33FF57', '#3357FF']
bg_colors = ['#FFE5B4', '#D5E8D4', '#D9EAD3']
sn.barplot(x='Track Score', y='Track', data=top_20det_Tr.head(20), ax=axes[0], palette='coolwarm')
axes[0].set_title('Track Score vs. Track')
axes[0].set_facecolor(bg_colors[0])
for spine in axes[0].spines.values():
    spine.set_edgecolor(spine_colors[0])
sn.barplot(x='Track Score', y='Album Name', data=top_20det_Tr.head(20), ax=axes[1], palette='viridis')
axes[1].set_title('Track Score vs. Album Name')
axes[1].set_facecolor(bg_colors[1])
for spine in axes[1].spines.values():
    spine.set_edgecolor(spine_colors[1])
sn.barplot(x='Track Score', y='Artist', data=top_20det_Tr.head(20), ax=axes[2], palette='magma')
axes[2].set_title('Track Score vs. Artist')
axes[2].set_facecolor(bg_colors[2])
for spine in axes[2].spines.values():
    spine.set_edgecolor(spine_colors[2])
plt.tight_layout()
plt.savefig(parent_directory + "/results/Track Score vs. Track-Track Score vs. Album Name-Track Score vs. Artist.png", bbox_inches='tight')
plt.show()


# In[40]:


plt.figure(figsize=(12, 8))
sn.lineplot(x='Track', y='Spotify Playlist Reach',data=df.head(20),hue="Artist",marker='o', color='red')

plt.gca().set_facecolor('white')  
plt.gca().spines['top'].set_color('b') 
plt.gca().spines['right'].set_color('b') 
plt.gca().spines['bottom'].set_color('b')  
plt.gca().spines['left'].set_color('b')  

plt.xlabel('Track', color='Red')
plt.ylabel('Spotify Playlist Reach', color='RED')

plt.xticks(color='blue',rotation =90) 
plt.yticks(color='blue')  

plt.title('Track vs Spotify Playlist Reach by Artist', color='blue')
plt.gcf().set_facecolor('white')  
plt.savefig(parent_directory + "/results/Track vs Spotify Playlist Reach by Artist.png", bbox_inches='tight')
plt.show()


# In[42]:


plt.figure(figsize=(12, 8))
sn.lineplot(x='Artist', y='Spotify Playlist Reach',data=df.head(15),hue="Album Name",marker='o', color='red',dashes=True)

plt.gca().set_facecolor('white')  
plt.gca().spines['top'].set_color('b') 
plt.gca().spines['right'].set_color('b') 
plt.gca().spines['bottom'].set_color('b')  
plt.gca().spines['left'].set_color('b') 

plt.xlabel('Artist', color='Red')
plt.ylabel('Spotify Playlist Reach', color='RED')
plt.xticks(color='blue',rotation =90) 
plt.yticks(color='blue')   

plt.title('Artist vs Spotify Playlist Reach by Albums', color='blue')
plt.gcf().set_facecolor('white')  
plt.savefig(parent_directory + "/results/Artist vs Spotify Playlist Reach by Albums.png", bbox_inches='tight')
plt.show()


# In[43]:


mp.figure(figsize=(12, 8))
sn.barplot(x='Track', y='Spotify Streams', data=df.head(20), hue="Artist", palette='Reds')
plt.gca().set_facecolor('white')  
plt.gca().spines['top'].set_color('b') 
plt.gca().spines['right'].set_color('b') 
plt.gca().spines['bottom'].set_color('b')  
plt.gca().spines['left'].set_color('b') 
plt.xlabel('Track', color='Red')
plt.ylabel('Spotify Stream Reach', color='Red')
plt.xticks(color='blue',rotation =90) 
plt.yticks(color='blue') 
plt.title('Track vs Spotify Streams Reach by Artist', color='blue')
plt.gcf().set_facecolor('white')
plt.savefig(parent_directory + "/results/Track vs Spotify Streams Reach by Artist.png", bbox_inches='tight')
plt.show()


# In[44]:


plt.figure(figsize=(12, 8))
sn.barplot(x='Artist', y='Spotify Popularity',data=df.head(20),hue="Album Name", palette='Reds')
plt.gca().set_facecolor('white')  
plt.gca().spines['top'].set_color('b') 
plt.gca().spines['right'].set_color('b') 
plt.gca().spines['bottom'].set_color('b')  
plt.gca().spines['left'].set_color('b') 
plt.xlabel('Artist', color='Red')
plt.ylabel('Spotify Popularity', color='Red')
plt.xticks(color='b', rotation=90)
plt.yticks(color='b')
plt.title('Artist vs Spotify Popularity by Albums', color='blue')
plt.gcf().set_facecolor('white')
plt.savefig(parent_directory + "/results/Artist vs Spotify Popularity by Albums.png", bbox_inches='tight')
plt.show()


# In[49]:


plt.figure(figsize=(12, 8))
sn.scatterplot(x='Artist', y='YouTube Views', data=df.head(20), hue="Album Name", palette='coolwarm', s=150)
plt.gca().set_facecolor('white')  
plt.gca().spines['top'].set_color('b') 
plt.gca().spines['right'].set_color('b') 
plt.gca().spines['bottom'].set_color('b')  
plt.gca().spines['left'].set_color('b') 

plt.xlabel('Artist', color='green')
plt.ylabel('YouTube Views', color='green')

plt.xticks(color='Black', rotation=45)
plt.yticks(color='Black')

plt.title('Artist vs YouTube Views by Albums', color='violet')

plt.gcf().set_facecolor('white')
plt.savefig(parent_directory + "/results/Artist vs YouTube Views by Albums.png", bbox_inches='tight')
plt.show()


# In[48]:


plt.figure(figsize=(12, 8))

sn.boxplot(x='Artist', y='YouTube Views', data=df.head(20), hue="Album Name", palette='Reds')

plt.gca().set_facecolor('white')
plt.gca().spines['top'].set_color('RED')
plt.gca().spines['right'].set_color('RED')
plt.gca().spines['bottom'].set_color('RED')
plt.gca().spines['left'].set_color('RED')

plt.xlabel('Artist', color='Red')
plt.ylabel('YouTube Views', color='Red')

plt.xticks(color='Black', rotation=90)
plt.yticks(color='Black')

plt.title('Artist vs YouTube Views  by Albums', color='blue')
plt.gcf().set_facecolor('white')
plt.savefig(parent_directory + "/results/Artist vs YouTube Views  by Albums.png", bbox_inches='tight')
plt.show()


# In[50]:


columns_to_clean = ['YouTube Likes', 'TikTok Posts', 'TikTok Likes', 'TikTok Views', 
                     'YouTube Playlist Reach', 'Apple Music Playlist Count', 
                     'AirPlay Spins', 'SiriusXM Spins', 'Deezer Playlist Count', 
                     'Deezer Playlist Reach', 'Amazon Playlist Count', 'Pandora Streams', 
                     'Pandora Track Stations', 'Soundcloud Streams', 'Shazam Counts', 'Explicit Track']

def clean_and_convert(column):
    df[column] = df[column].replace('[\$,]', '', regex=True).astype(float)

for column in columns_to_clean:
    clean_and_convert(column)

numeric_df = df[columns_to_clean].head(20)
corr_matrix = numeric_df.corr()

plt.figure(figsize=(12, 8))
sn.heatmap(corr_matrix, annot=True, cmap='coolwarm', center=0)
plt.gca().set_facecolor('white')
plt.gca().spines['top'].set_color('blue')
plt.gca().spines['right'].set_color('blue')
plt.gca().spines['bottom'].set_color('green')
plt.gca().spines['left'].set_color('green')
plt.xlabel('Features', color='darkred')
plt.ylabel('Features', color='darkred')
plt.xticks(color='purple')
plt.yticks(color='purple')
plt.title('Correlation Heatmap of Features', color='orange')
plt.gcf().set_facecolor('white')
plt.savefig(parent_directory + "/results/Correlation Heatmap of Features.png", bbox_inches='tight')
plt.show()


# In[51]:


numeric_df


# In[ ]:




