# Spotify Song Popularity Prediction

This project aims to predict the popularity of Spotify songs in 2024 based on various features such as streaming counts, playlist reach, and social media engagement. A `RandomForestRegressor` model is used to predict the target variable, which is the 'Spotify Popularity' feature.

## Table of Contents

- [Overview](#overview)
- [Getting Started](#getting-started)
- [Data Preprocessing](#data-preprocessing)
- [Model Training and Evaluation](#model-training-and-evaluation)
- [Evaluation Metrics](#evaluation-metrics)
- [Results Visualization](#results-visualization)


## Overview

This repository contains code that processes Spotify song data, builds a machine learning model to predict song popularity, and evaluates the model's performance.

The key tasks include:
1. Data cleaning and preprocessing
2. Feature selection and encoding
3. Model training using `RandomForestRegressor`
4. Model evaluation using multiple metrics
5. Visualization of predictions

## Getting Started

To get started with this project, ensure you have Python 3.x installed along with the following dependencies:

pip install pandas seaborn matplotlib scikit-learn

## Data Preprocessing
The data is loaded from a CSV file, and several preprocessing steps are performed:

1. Handling Missing Values:
Columns with over 50% missing values are dropped.
Rows with missing 'Spotify Popularity' values are also removed.
2. Feature Encoding:
Categorical features (like 'Artist') are encoded using LabelEncoder to make them suitable for machine learning models.
3. Data Cleaning:
Comma characters in object-type columns are removed.
The remaining columns are converted to numeric values.

## Results Visualization
The predictions are visualized using a scatter plot, comparing the true values vs. predicted values. A red 45-degree line is plotted to show perfect predictions.

## Model Training and Evaluation
1. Training the Model:
The dataset is split into training and testing sets (80% train, 20% test).
A RandomForestRegressor model is trained using the training data.
2. Model Evaluation:
The model is evaluated using the following metrics:
Mean Absolute Error (MAE)
Mean Squared Error (MSE)
Root Mean Squared Error (RMSE)
R² Score

## Future Improvements
Here are some potential improvements for future iterations of the project:

Hyperparameter Tuning: Use GridSearchCV or RandomizedSearchCV to tune hyperparameters and improve model performance.
Cross-Validation: Implement cross-validation to ensure the model generalizes well to unseen data.
Feature Importance: Visualize and interpret feature importances to understand which variables contribute most to predictions.
Model Comparison: Test other regression models (e.g., GradientBoostingRegressor, XGBoost) to compare performance.